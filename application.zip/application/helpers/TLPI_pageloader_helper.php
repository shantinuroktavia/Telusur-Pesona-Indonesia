<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if ( ! function_exists('load_view'))
{
  function load_view($viewname,$data)
  {
    $ci=& get_instance();
    $data['body'] = $viewname;
    $ci->load->vars($data);

    $user_cookie = $ci->input->cookie('TelusurPesonaIndonesia',false);
    if($user_cookie==false){
      $ci->load->view('headerUmum');
    }else{
      $ci->load->view('headerAnggota');
    }
  }

  function get_username($id){
    $ci=& get_instance();
    $ci->load->model('Anggota_Model');
    $arr = $ci->Anggota_Model->getDataAnggota($id);
    return $arr['Username'];
  }
}
