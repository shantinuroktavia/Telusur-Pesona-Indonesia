



<div class = "lokasi">
<img id="Image-Maps-Com-image-maps-2014-04-12-205631" src="http://www.image-maps.com/m/private/0/73f5f2ckcpb45dvj8vnn4uo5c5_peta-indonesia.jpg" border="0" width="1055" height="412" orgWidth="1055" orgHeight="412" usemap="#image-maps-2014-04-12-205631" alt="" />
<map name="image-maps-2014-04-12-205631" id="ImageMapsCom-image-maps-2014-04-12-205631">
<area shape="rect" coords="1053,410,1055,412" alt="Image Map" style="outline:none;" title="Image Map" href="http://www.image-maps.com/index.php?aff=mapped_users_0" />
<area  alt="" title="Taman Nasional Gede Pangrango, Bogor, Jawa Barat" href="<?php echo site_url('/tamannasional/1100200003');?>" shape="poly" coords="284,306,283,312,290,306,283,309,286,304,290,311,288,312" style="outline:none;" target="_self"     />
<area  alt="" title="Taman Nasional Lore Lindu, Sulawesi Tengah" href="<?php echo site_url('/tamannasional/1100500001');?>" shape="poly" coords="584,203,576,203,584,198,581,191,576,193,574,198,591,197,581,209,574,204,597,205,573,194,580,189" style="outline:none;" target="_self"     />
<area  alt="" title="Taman Nasional Alas Purwo, Jawa Timur" href="<?php echo site_url('/tamannasional/1100200012');?>" shape="poly" coords="442,355,447,351,442,350,441,355,436,352,440,348,447,348" style="outline:none;" target="_self"     />
<area  alt="" title="Taman Nasional Ujung Kulon, Banten, Jawa Barat" href="<?php echo site_url('/tamannasional/1100200001');?>" shape="poly" coords="245,315,253,312,248,312,253,311,255,319,259,314,254,309,259,315" style="outline:none;" target="_self"     />
<area  alt="" title="Taman Nasional Bukit Barisan Selatan, Bengkulu" href="<?php echo site_url('/tamannasional/1100100003');?>" shape="poly" coords="254,252,249,255,243,255,250,249,233,251,224,251,221,255,205,256,219,259,218,248,251,242,239,258,233,259,254,239,229,258,213,251,210,251,212,262,206,264,202,259,257,234,196,256,192,254,192,252" style="outline:none;" target="_self"     />
</map>
</div>


<!-- Gede Pangrango
lorelyndu
Alas Purwo
Bukit Barisan Selatan
Ujung Kulon -->
